﻿
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using System.Collections.ObjectModel;
using System.ComponentModel;

namespace MauiTaskApp.ViewModel
{
    public partial class MainViewModel : ObservableObject
    {
        //构造函数
        public MainViewModel()
        {
            Items = new ObservableCollection<string>();
        }

        [ObservableProperty]
        ObservableCollection<string> items; //加了注解,就会生成公共的Items属性

        [ObservableProperty]
        string text;
        //创建命令
       [RelayCommand]
       void Add()
       {
            if (string.IsNullOrWhiteSpace(Text))
                return;
            Items.Add(Text);
            //添加新项
            Text = string.Empty;
       }
    }
}
