﻿using MauiTaskApp.ViewModel;

namespace MauiTaskApp
{
    public partial class MainPage : ContentPage
    {

        public MainPage(MainViewModel vm)
        {
            InitializeComponent();
            //给绑定上下文赋值
            BindingContext = vm;
        }

    }

}
