﻿
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using System.Collections.ObjectModel;
using System.ComponentModel;
using Microsoft.Maui.Controls;

namespace MauiTaskApp.ViewModel
{
    public partial class MainViewModel : ObservableObject
    {
        IConnectivity connectivity;
        //构造函数
        public MainViewModel(IConnectivity connectivity)
        {
            Items = new ObservableCollection<string>();
            this.connectivity = connectivity;
        }

        [ObservableProperty]
        ObservableCollection<string> items; //加了注解,就会生成公共的Items属性

        [ObservableProperty]
        string text;
        //创建命令
       [RelayCommand]
       async Task Add()
       {
            if (string.IsNullOrWhiteSpace(Text))
                return;
            //判断是否有网络连接
            if(connectivity.NetworkAccess != NetworkAccess.Internet)
            {
                await Shell.Current.DisplayAlert("No internet!", "Oops,You need Internet!!!", "OK");
                return;
            }
            Items.Add(Text);
            //添加新项
            Text = string.Empty;
       }

        [RelayCommand]
        async void Delete(string s)
        {
            //在ViewModel中由于不是控件,所以需要借助Shell来弹出警告框.而且获取他的返回值最好使用async-await的方式
            var ret =await Shell.Current.DisplayAlert("请确认", "删除"+s+"?", "Yes", "No");
            if (ret==true)
            {
                if (Items.Contains(s))
                {
                    Items.Remove(s);
                }
            }
            
        }

        [RelayCommand]
        async Task Tap(string s)
        {
            await Shell.Current.GoToAsync($"{nameof(DetailPage)}?Text={s}");
        }
    }
}
