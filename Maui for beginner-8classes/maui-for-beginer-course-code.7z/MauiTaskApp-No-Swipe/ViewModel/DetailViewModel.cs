﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;

namespace MauiTaskApp.ViewModel
{
    [QueryProperty("Text","Text")]
    public partial class DetailViewModel:ObservableObject 
    {
        [ObservableProperty]
        string text;

        [RelayCommand]
        async Task GoBack() //返回MainPage
        {
            await Shell.Current.GoToAsync("..");
        }
    }
}
