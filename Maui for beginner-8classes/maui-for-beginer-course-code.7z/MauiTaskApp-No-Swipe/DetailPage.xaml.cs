using MauiTaskApp.ViewModel;

namespace MauiTaskApp;

public partial class DetailPage : ContentPage
{
	public DetailPage(DetailViewModel vm) 
	{
		InitializeComponent();
		BindingContext = vm;
	}
}